# -*- coding: utf-8 -*-

"""

    SPDX-License-Identifier: Apache-2.0
    See LICENSES/Apache-2.0.txt for more information.

"""

__all__ = ['distro']
