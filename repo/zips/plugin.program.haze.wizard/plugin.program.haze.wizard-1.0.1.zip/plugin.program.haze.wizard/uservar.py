'''#####-----Build File-----#####'''
buildfile = 'http://'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.program.haze.wizard,repository.haze']
