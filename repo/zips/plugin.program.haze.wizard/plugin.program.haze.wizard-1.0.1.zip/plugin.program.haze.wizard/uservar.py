'''#####-----Build File-----#####'''
buildfile = 'http://raw.githubusercontent.com/AnimaHaze/repository.haze.repo/main/repo/builds/builds.json'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/AnimaHaze/repository.haze.repo/main/repo/builds/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.program.haze.wizard,repository.haze']
