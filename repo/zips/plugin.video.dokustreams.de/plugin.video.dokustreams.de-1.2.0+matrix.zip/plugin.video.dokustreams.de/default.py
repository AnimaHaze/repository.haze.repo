from resources.lib.dokustreams import main


if __name__ == '__main__':
    main()
